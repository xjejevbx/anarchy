extends Node2D
## Racine du jeu : assemble le monde, le joueur, les monstres et le HUD.

# --- Réglages de la partie (la saisie de la seed viendra avec le menu de création) ---
const WORLD_SEED_TEXT: String = "cataclysme"  # nombre ou texte : même seed = même monde
const USE_TEST_ARENA: bool = false           # true : ancienne carte fermée 60x40 (debug)


func _ready() -> void:
	var world := World.new()
	world.world_seed = WorldRng.seed_from_text(WORLD_SEED_TEXT)
	world.use_arena = USE_TEST_ARENA
	add_child(world)

	var player := Player.new()
	player.world = world
	world.player = player
	world.add_entity(player)  # dans le calque trié par Y, avec les monstres et les arbres

	var inventory_ui := InventoryUI.new()
	inventory_ui.player = player
	add_child(inventory_ui)

	var hud := CanvasLayer.new()
	hud.set_script(load("res://scripts/ui/hud.gd"))
	add_child(hud)

	EventBus.message_logged.emit("Monde : seed « %s » (%d)%s." % [WORLD_SEED_TEXT, world.world_seed, ", arène de test" if USE_TEST_ARENA else ""])

	# Quelques zombies pour tester
	world.spawn_monster(MonsterData.zombie(), Vector2i(14, 8))
	world.spawn_monster(MonsterData.zombie(), Vector2i(20, 14))
	world.spawn_monster(MonsterData.zombie(), Vector2i(10, 20))

	# Objets de test au sol, autour du joueur (5, 5) : I = inventaire, G = ramasser
	world.add_ground_item(Vector2i(6, 5), Item.create("backpack_military"))
	world.add_ground_item(Vector2i(6, 5), Item.create("backpack"))
	world.add_ground_item(Vector2i(6, 5), Item.create("bag_curtain"))
	world.add_ground_item(Vector2i(5, 6), Item.create("jacket_light"))
	world.add_ground_item(Vector2i(5, 6), Item.create("pants_cargo"))
	world.add_ground_item(Vector2i(5, 6), Item.create("hat_ball"))
	world.add_ground_item(Vector2i(4, 5), Item.create("2x4"))
	world.add_ground_item(Vector2i(4, 5), Item.create("sheet_metal_small"))
	world.add_ground_item(Vector2i(4, 5), Item.create("pipe"))
	world.add_ground_item(Vector2i(4, 5), Item.create("stick"))
	world.add_ground_item(Vector2i(5, 4), Item.create("can_beans", 4))
	world.add_ground_item(Vector2i(5, 4), Item.create("bottle_plastic", 2))
	world.add_ground_item(Vector2i(5, 4), Item.create("rope_6"))
