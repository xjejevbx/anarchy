extends SceneTree
## Test de déterminisme de la génération (docs/WORLD_GEN.md §3, jalon 1). À lancer à la demande :
##   godot --headless --path <projet> --script res://tests/test_worldgen_determinism.gd
## Code de sortie 0 = tout est bon.

const RANGE: int = 4  # chunks de -4 à +4 dans les deux axes (81 chunks)

var _failures: int = 0


func _initialize() -> void:
	var seeds: Array[int] = []
	for text in ["1", "42", "cataclysme", "", "-7"]:
		seeds.append(WorldRng.seed_from_text(text))
	var keys: Array[Vector3i] = []
	for y in range(-RANGE, RANGE + 1):
		for x in range(-RANGE, RANGE + 1):
			keys.append(Vector3i(x, y, 0))

	for world_seed in seeds:
		# Trois ordres de génération différents : ligne par ligne, inversé, par distance au centre.
		var in_order: Dictionary = _fingerprints(world_seed, keys)
		var reversed_keys: Array[Vector3i] = keys.duplicate()
		reversed_keys.reverse()
		var in_reverse: Dictionary = _fingerprints(world_seed, reversed_keys)
		var by_distance: Array[Vector3i] = keys.duplicate()
		by_distance.sort_custom(func(a: Vector3i, b: Vector3i) -> bool:
			return a.x * a.x + a.y * a.y < b.x * b.x + b.y * b.y)
		var in_spiral: Dictionary = _fingerprints(world_seed, by_distance)
		_check(in_order == in_reverse, "seed %d : ordre normal = ordre inversé" % world_seed)
		_check(in_order == in_spiral, "seed %d : ordre normal = ordre par distance" % world_seed)
		_check(in_order == _fingerprints(world_seed, keys), "seed %d : deux générations identiques" % world_seed)

	# Des seeds différentes doivent donner des mondes différents.
	var a: Dictionary = _fingerprints(seeds[0], keys)
	var b: Dictionary = _fingerprints(seeds[1], keys)
	_check(a != b, "seeds 1 et 42 : mondes différents")

	# Densité d'arbres plausible (réglage ChunkGenerator.TREE_DENSITY).
	var trees: int = 0
	var total: int = 0
	var tree_index: int = TerrainDB.index_of("t_tree")
	for key in keys:
		for byte: int in ChunkGenerator.generate(seeds[2], key):
			total += 1
			if byte == tree_index:
				trees += 1
	var ratio: float = float(trees) / float(total)
	_check(absf(ratio - ChunkGenerator.TREE_DENSITY) < 0.02, "densité d'arbres %.3f proche de %.2f" % [ratio, ChunkGenerator.TREE_DENSITY])

	# Zone de départ dégagée.
	var spawn_chunk: Vector3i = Vector3i(0, 0, 0)
	var spawn_data: PackedByteArray = ChunkGenerator.generate(seeds[2], spawn_chunk)
	var spawn_index: int = ChunkGenerator.SPAWN_POS.y * Chunk.SIZE + ChunkGenerator.SPAWN_POS.x
	_check(spawn_data[spawn_index] == TerrainDB.index_of("t_grass"), "le point de départ est de l'herbe")

	# Arène : bordure en murs, intérieur praticable, déterministe.
	var wall: int = TerrainDB.index_of("t_wall_arena")
	var arena_data: PackedByteArray = ChunkGenerator.generate(0, Vector3i(0, 0, 0), true)
	_check(arena_data[0] == wall, "arène : la case (0,0) est un mur")
	_check(arena_data[5 * Chunk.SIZE + 5] != wall, "arène : la case (5,5) est praticable")
	_check(ChunkGenerator.fingerprint(0, Vector3i(1, 1, 0), true) == ChunkGenerator.fingerprint(0, Vector3i(1, 1, 0), true), "arène : déterministe")

	# Le RNG de base : stable et bien réparti.
	_check(WorldRng.mix(1, 2, 3, 4, 5) == WorldRng.mix(1, 2, 3, 4, 5), "mix : stable")
	_check(WorldRng.mix(1, 2, 3, 4, 5) != WorldRng.mix(1, 2, 3, 4, 6), "mix : sensible à chaque paramètre")
	_check(WorldRng.seed_from_text("42") == 42, "seed_from_text : un entier reste tel quel")
	_check(WorldRng.seed_from_text("abc") == WorldRng.seed_from_text("abc"), "seed_from_text : texte stable")

	print("RÉSULTAT : %s (%d échec(s))" % ["OK" if _failures == 0 else "ÉCHEC", _failures])
	quit(_failures)


func _fingerprints(world_seed: int, keys: Array[Vector3i]) -> Dictionary:
	var result: Dictionary = {}
	for key in keys:
		result[key] = ChunkGenerator.fingerprint(world_seed, key)
	return result


func _check(condition: bool, label: String) -> void:
	if condition:
		print("  ok   - ", label)
	else:
		print("  ECHEC - ", label)
		_failures += 1
